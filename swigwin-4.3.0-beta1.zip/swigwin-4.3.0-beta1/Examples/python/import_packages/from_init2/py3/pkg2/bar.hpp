#ifndef PY3_PKG2_BAR_HPP
#define PY3_PKG2_BAR_HPP
#include "../../py3/pkg2/pkg3/foo.hpp"
struct Pkg2_Bar : Pkg3_Foo {};
#endif /* PY3_PKG2_BAR_HPP */
