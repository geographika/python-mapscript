
int foofunction(int i) {
  return i *= 10;
}

struct FooClass {
  int foomethod(int i) {
    return i += 5;
  }
};
