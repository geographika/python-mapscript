#ifndef PY2_PKG2_PKG3_PKG4
#define PY2_PKG2_PKG3_PKG4
struct Pkg4_Foo {};
#endif /* PY2_PKG2_PKG3_PKG4 */
