#ifndef PY3_PKG2_HPP
#define PY3_PKG2_HPP
#include "../../py3/pkg2/pkg3/pkg4/foo.hpp"
struct Pkg2_Bar : Pkg4_Foo {};
#endif /* PY3_PKG2_HPP */
